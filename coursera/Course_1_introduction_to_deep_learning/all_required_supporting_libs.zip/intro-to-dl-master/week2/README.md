If you've started the course after **August 13, 2018**, you should use the files
in the `v2` folder for all assignments, **except** honor assignment.